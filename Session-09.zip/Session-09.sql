use  hrms


-- join 


select * from employee 
select * from salary 

--inner join : is also know equi or equal join 
-- inner join is also known as default  join or exact match 

select * 
from employee  e join  salary s 
	on e.EID = s.EID 

--inner 
select * 
from employee  e inner join  salary s 
	on e.EID = s.EID 

select * 
from salary s  inner join    employee  e
	on e.EID = s.EID 


---
select e.eid , e.FNAME, e.LNAME
from salary s  inner join    employee  e
	on e.EID = s.EID 

select *
from salary s  inner join    employee  e
	on e.EID = s.EID 

--with condition : this syntax is not recommended
select *
from salary s  inner join    employee  e
	on e.EID = s.EID 
where s.basic >100

--this syntax is recommend
select *
from salary s  inner join    employee  e
	on e.EID = s.EID 
	 and s.basic >100 --and --or --and  ...   in ... betweeen .. 
		

--cartisan product  : strongly not recommended 
select * 
from salary,employee
where salary.eid = employee.eid 

/*
t1
1 a
2 b

t2
1 100
2  300
3  400
out 
1 a 1 100
1 a 2 300
1 a 2 400
2 b 2 300
3 b 3 400

1 a 1 100
2 b 2 300

*/

-- multiple table join 
select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC,c.CNAME
from employee  e join  salary s 
	on e.EID = s.EID 
	inner join Country c
		on e.cid= c.cid 

select * from Country


----  left join 
select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC
from employee  e left join  salary s 
	on e.EID = s.EID 

	--left join or left outer join both are same 
select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC
from employee  e left outer join  salary s 
	on e.EID = s.EID 

---right join 
select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC
from employee  e right join  salary s 
	on e.EID = s.EID 

--right join or right outer join both are same 
select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC
from employee  e right outer join  salary s 
	on e.EID = s.EID 


--full outer join  and full join both are same 
select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC
from employee  e full join  salary s 
	on e.EID = s.EID 

select e.DOB , e.EMAILID, e.FNAME,s.DA,s.BASIC
from employee  e full outer join  salary s 
	on e.EID = s.EID 

--
select * from employee 
select * from salary 

-- error 
select e.EID, e.FNAME, s.basic
from employee  e left outer join  salary s 
	on e.EID = s.EID 
	and s.basic is null 

select * from employee


select e.eid, e.fname, s.basic
from employee  e left join  salary s 
	on e.EID = s.EID 
where s.BASIC is null 



select e.EID, e.FNAME,s.BASIC
from employee  e right join  salary s 
	on e.EID = s.EID
	and s.BASIC is not null 



/*
Type SQL Server
		- Database engine		: OLTP 
				-- MS BI 
		- IS/SSIS				: etl loop
		- RS/SSRS				: reporting tool
		- AS/SSAS				: analysis		: OLAP(online analysis processing) 
							
WebApp/MobApp/App -> BackEnd(database/OLTP) -> DW   ->   SSAS  (dimenssion(text,descriptive) 
															, measure (numeric) )   
															 cube (is collection of dimenssion and meas)


			
*/

