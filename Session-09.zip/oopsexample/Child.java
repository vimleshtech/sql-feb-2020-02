package oopsexample;

public  class Child  extends FinalKeywords{

	 void add(int a, int b) {
		 System.out.println("test add");
	 }
	 //void mul(int a, int b) { //overwrite not allowd for final function 
		 
	 //}
}

