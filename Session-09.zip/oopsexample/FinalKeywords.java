package oopsexample;

public  class FinalKeywords {

	final double taxperct= .10; //read only 
	
	void tax(int amt) {
		
		double tax =amt*taxperct;
		System.out.println(tax);
		//taxperct =1;
		
	}
	//final function fannot be overwrite
	final void mul(int a, int b) {
		System.out.println(a*b);
	}
}
