package oopsexample;

import java.io.File;
import java.lang.ref.WeakReference;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StaticExample o1 = new StaticExample();
		StaticExample o2 = new StaticExample();
		
		o1.a =1;
		o1.b =1;
		
		o2.a =2;
		o2.b =2;
		System.out.println(o1.a);//1
		System.out.println(o1.b);//2
		
		System.out.println(o2.a); //2
		System.out.println(o2.b); //2
		
		StaticExample.sub(11, 2);
		//StaticExample.add(11,33) ; //not allowd
		o1.add(11, 2);
		
		
		FinalKeywords f =new FinalKeywords();
		f.tax(1000);
		
		
		WrapperClass w = new WrapperClass();
		WrapperClass.Tax o = w.new Tax();
		o.tax(11);
		 
		WrapperClass.DCal.mul(11, 2);
		
		System.out.print("");
		
	}

}
