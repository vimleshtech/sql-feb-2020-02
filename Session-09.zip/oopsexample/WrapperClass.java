package oopsexample;

import javax.swing.plaf.SplitPaneUI;

public class WrapperClass {

	
	public class Tax{
		
		void tax(int amt) {
			System.out.println(amt*.10);
		}
		
	}
	public static class DCal{

		static void mul(int a, int b) {
			System.out.println(a*b);
		}
		void tax(int amt) {
			System.out.println(amt*.10);
		}
		
	}
}
