package oopsexample;

public class StaticExample {

	//static allocate single memory
	int a;
	static int b;
	//static data member and function can be access without object 
	
	void add(int x, int y) {
		System.out.println(x+y);
	}
	static void sub(int x, int  y) {
		System.out.println(x-y);
	}
	
}
