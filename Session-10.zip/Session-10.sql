/*
where vs group up vs having

delete vs trunate 
	- delete support where clause (we can remove all rows or selected rows)
	  however truncate don't support where caluase (we can remove all rows, but not selected rows)
	- delete don't rest auto increment column (indentity column)
	  howevere truncate does reset auto increment column (indentity column)
	- delete and truncate both can be rollback
	- trigger will not executed after/with truncate command/statement
	- truncate doesn't store the log 

view  : is virtual table which contains/store the structure but not data 
	  : view can be use as a wrapper of table 
	  : view can be use a physical table 
	
TCL    
	
EXCEPT VS common  
	- table structure should be same 

select * from t1
exept 
select * from t2



select * from t1
commont (not keyword)
select * from t2

 
*/


use hrms 


select * from emp_copy

begin tran 

truncate table emp_copy

rollback


-- TCL : transaction control language 
-- begin tran/ transaction		: start recording 
-- commit						: save 
-- rollback						: calcel/ undo 


select * From c_employee1

begin tran 
			
	begin tran 
			--select * From emp_copy
		update c_employee1
		set gender = 'female'
		where eid =10

	rollback 

	begin tran 

						delete from c_employee1
	--commit 

rollback 

begin tran 
update employee
set phone =5466666
where id =11

select * from employee 

--commit 
rollback 

sp_who2


--CREATE VIEW

SELECT * FROM C_EMPLOYEE 
SELECT * FROM SALARY 

CREATE VIEW V_MYDATA
AS
SELECT E.EMPNAME, E.ADDRESS, S.BASIC
FROM C_EMPLOYEE  AS E INNER JOIN SALARY  AS S 
	ON E.EMPID = S.EID 



SELECT * fROM V_MYDATA


