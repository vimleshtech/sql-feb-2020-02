/*
 
 wild card / like : is also known as pattern matching
 case when  : is decision making statement or conditional statement
 keywords
	top
	distinct
	select into

aggregiate function 
*/

use hrms 

select * from employee

-- wildcard :  
-- %   any length and any chars/digit
-- _   fix length and any chars/digit

--show all rows where name start from a 
select * from employee where fname like 'a%'

--show all rows where name ending with a
select * from employee where fname like '%a'

--contains a (anywhere a should present)
select * from employee where fname like '%a%'

-- -- 
select * from employee where fname like '____a'

-- where 2nd char is a 
select * from employee where fname like '_a%'

--show list of email id which start with a and ending with @gmail.com
select * from employee where emailid  like 'a%@gmail.com'

select * from employee where emailid  like '_a%@gmail.com'  -- 2nd position a 

select * from employee where emailid  like '%@%.com'  -- 2nd position a 
							emailid='akjfhjfhhf%fkjhfhgfh@gmail.com'

select * from employee where emailid  like '%''%''%'  

select * from employee where emailid  like '%''%''%'  

select 'ram''s' 

--- case when 
select 
	eid
	,fname
	,MNAME
	,case when gender ='male' 
		   then 
				'm' 
			else 
				null 
	end 
	from employee 


select * from C_Employee

select empid, empname, Salary,
	case when Salary>25000
		  then 
			salary *1.10

			else case when Salary >22000 
				then 
					salary *1.12
				else 
					salary *1.15
				end 
	end	as newsal
from C_Employee


select empid, empname, Salary,
	case when Salary>25000 and salary <30000
		  then 
				salary *1.10
			else case when Salary >22000 
				then 
					salary *1.12
				else 
					salary *1.15 -- (select top 1 col1 from abxshjf )
				end 
	end	as newsal
from C_Employee


-- keywords    : is reserved words 
-- top         :  return given number of rows 
select * from C_Employee
select  top 1 * from C_Employee 
select  top 2 * from C_Employee 
select  top 1 empname, address  from C_Employee 


select  * from C_Employee order by empname desc 
select  top 2 * from C_Employee order by empname desc 

select  * from C_Employee order by empname asc

-- distinct    : return unique row or value 
select distinct * from C_Employee 
select distinct  salary  from C_Employee 

-- select into : create new table from existing table
--insert data in new table from existing table
select * into newcopy  from C_Employee  
select * From newcopy  

select * into newcopy3  from C_Employee  where empid >10 

select empname,salary into newcopy3  from C_Employee  where empid >10 

-- insert data from exinting table to exiting table
insert into newcopy 
select * From C_Employee

-- aggregiate function 
 -- max(), min(), sum(), avg(), count()  etc.
 select * from employee 

 select gender , count(gender), sum(eid),min(eid),max(eid) from employee group by gender 

 select status_id, count(status_id) from employee 
 group by status_id 


 
 select status_id, count(*) from employee 
 group by status_id 
 having count(*)>1




 select count(*) from employee
 select count(fname) from employee

 select count(*) from employee
 select count(STATUS_ID) from employee





