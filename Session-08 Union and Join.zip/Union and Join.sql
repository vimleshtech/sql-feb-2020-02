/*


*/
use hrms 

select * from proudcts
select * from transactions
select * from proudcts as p

-----
-----
select * from transactions

select count(*) from transactions

select *,(select count(*) from transactions )  from product_master

select * from transactions
select * from product_master

select *,(select count(*) from transactions where tid = pid )  from product_master

select *,(select count(*) from transactions where tid = p.pid )  from product_master p 

/*
union: to merge two or more than two tables vertically
	 - table structure should be same(no of columns and data type)
	 there are following types of union
			i. union		: return unique rows 
			ii. union all	: return all rows 
	 					 
join: to merge two or more than two tables horizentally based on common column
    - at least one column should be same in both the sources 
	There are following types of join
			i. inner join			
					:return common or matching rows 
			ii. outer join / full outer join 
					: return all rows from both tables					
					a. left join  / left outer join
					: return all rows from left table and matching from right table
					b right join / right outer join 
					: return all rows from right table and matching from left table


*/

select * into empcopy from employee 

select * from employee 
union 
select * from empcopy 



select * from employee 
union  all
select * from empcopy 



select 1
union 
select 2
union 
select 1
union 
select 3


select 1
union  all
select 2
union all
select 1
union all
select 3


select eid,fname from employee 
union 
select eid,fname from empcopy 

union 
select eid,fname from empcopy 
union 
select eid,fname from empcopy 
union 
select eid,fname from empcopy 
union 
select eid,fname from empcopy 


select * from employee


select * from salary 

select e.eid, e.fname, s.BASIC
from employee as e inner join salary as s 
on e.eid = s.eid 
