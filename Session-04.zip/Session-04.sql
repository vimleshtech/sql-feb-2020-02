/*
Today's Topics
----------------------
SQL Command Types:
	DDL :  data definition langauge
			- create	: create new object
			- alter		: modify the struture of existing object
			- drop		: remove object
			- truncate  : remove all data from table, but structure(header) will remain same
	DML	: data manipulation language
			- insert	: save new row in a table
			- update	: update existing data/value
			- delete	: delet row (with conidtion/selected rows, and without condition / all rows)
	DCL	: data control language (decision control langauage)
			- create user
			- grant access
			- revoke access
	TCL	: transaction control langauge 
			- begin transaction 
			- commit
			- rollback 
	DQL	: data query langauge 
			- select	: view data 
Operator
		conditional
			>
			>=
			<
			<=	
			in 
			not in
			between
			no between
			is equal
			is not equal
			=
		logical
			and 
			or 
					
WildCard / Like
			
Case when 
keywords
	distinct
	top
	select into 
Aggregiate function 
*/

--- create	: create new object
--create new database 
create database sales_db;

--switch database 
use sales_db

--create new table 
create table customer
(
cid int identity(1,1) primary key,
fname varchar(30) not null,
lname varchar(30) null,
email varchar(100) unique,
gender char(1) check (gender in ('M','F')),
creat_date   datetime default getdate()
)


create table product
(
pid int identity(1,1) primary key,
pname varchar(30) not null,
pprice int not null,
sprice int not null,
)

create table sales_order
(
oid int identity(1,1) primary key,
cid  int foreign key references customer(cid),
pid int foreign key references product(pid),
qty int not null,
odate datetime default getdate()
)



-- insert data in tables
insert into customer(fname,email)
values('Jatin','jatin@gmail.com'),
('Monika','monika@gmail.com'),
('Nitisha','nitisha@gmail.com'),
('Raman','ramanb@gmail.com')

select * from customer

insert into product(pname,pprice,sprice)
values('Iphone',70000,80000),
('Mac-laptop',170000,180000),
('Dell-laptop',30000,40000),
('Hp-laptop',40000,50000)


--in sales order
insert into sales_order(cid,pid,qty)
values(1,2,5),(2,1,15),(4,3,2)


select * from customer
select * from product
select * from sales_order

--- alter		: modify the struture of existing object
--alter table and add new columns 
alter table customer 
add country varchar(100), dob datetime

-- alter table and change data type 
alter table customer 
alter column country varchar(30) 

--update data existing value
update customer
set country ='india'

update customer
set country ='us'
where cid in (1,3)

-- alter table and drop column
alter table customer 
drop column country


select * from sales_order 
-- delete vs truncate 
-- delete : 
-- delete selected rows 
	delete from sales_order where oid  =2 
--delete all rows 
	delete from sales_order 
--delete doesn't reset auto increment (identity) field 

--truncate 
--trunate all rows, truncate doesn't support where calause (conditional delete is allowed)
truncate table sales_order 
--truncate reset the auto increment field 


--projection : to view selected columns
select * from customer 
select cid,email,fname from customer 
select cid as customer_id ,email,fname from customer  --with alias
select cid  customer_id ,email,fname from customer  --with alias


 

--selection 
select * from customer 
select * from customer where cid =1
select * from customer where cid >1
select * from customer where cid >=2
select * from customer where cid <2
select * from customer where cid <=1
select * from customer where cid in (1,3,5)
select * from customer where cid not in (1,3,5)
select * from customer where cid between 2 and 4 
select * from customer where cid not between 2 and 4 

select * from customer where dob is null  -- is not same select * from customer where dob = null 
select * from customer where dob is not null 


-- and 1 ,  or 2
select * from customer where cid>2 and gender='f'
select * from customer where cid>2 or gender='f'

select * from customer where  gender='f' and dob is null
select * from customer where cid>2 or gender='f' and dob is null
select * from customer where (cid>2 or gender='f') and dob is null


select * from customer where cid+1<1

 


update customer 

set gender ='f'
where cid in (2,3)

update customer 
set gender ='m'
where cid not  in (2,3)


update customer 
set dob ='1990-11-01'
where cid in (1,4)

sp_help customer 

select * from customer 

