
/*
where 
order by
group by
having 

Sequence:

6. select  columns(order by dependens on column)
1.from
2. where   / filter  data from table
3. group by 
4. having  / filter data after group by(summarizing data), having cannot be use without group by
5. order by   / in which squence you want to show data 
*/

use hrms 


--where 
select * from employee 
where status_id ='active'

--order  by
--
select * from employee 
order by gender  --default is asc 

select * from employee 
order by gender  desc 

-- where and order by 
select * from employee 
where status_id ='active'
order by gender desc 

--group by : count status wise count
select STATUS_ID, count(status_id)
from employee 
group by status_id 

--show the status where count is not 0
select STATUS_ID, count(status_id)
from employee 
group by status_id 
having count(status_id)>0


----select * from employee
select STATUS_ID, count(status_id)
from employee 
where gender ='female'
group by status_id 
having count(status_id)>0




select STATUS_ID, count(status_id) 
from employee 
where gender ='female'
group by status_id 
having count(status_id)>0
order by 2  desc 



